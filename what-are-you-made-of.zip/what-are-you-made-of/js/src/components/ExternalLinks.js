/**
 * Find links that have an external link and make them safely open in a new tab.
 */
var ExternalLinks = {
    host: '',
    links: [],

    init: function() {
        // Get the current host
        this.host = window.location.host;
        // find all links
        this.links = Array.from(document.querySelectorAll('a[href^="http"]'));
        // Parse all links
        this.parse();
    },

    parse: function() {
        this.links.forEach((link) => {
            // Check if each host is equal to the current host.
            if(link.host !== ExternalLinks.host) {
                link.rel = 'noopener noreferrer';
                link.target = '_blank';
            }
        });
    }
};

export default ExternalLinks;
