import ScrollHandler from './ScrollHandler';

/**
 * The navigation bar at the bottom of the page.
 *
 * 1. When a user clicks on a link, the slider needs to scroll to that link.
 * 2. When a user slides into a new section, the navigation needs to follow suit.
 *
 * @type {Object}
 */
const Navigation = {
    navLink: '.js-nav-link',
    links: [],
    navSlides: [],
    slides: [],
    currentSlideIndex: 0,
    nextSlideIndex: null,
    currentSection: '',
    init() {
        this.navSlides = Array.from(document.querySelectorAll('.slide[id]'));
        this.links = Array.from(document.querySelectorAll(this.navLink));

        let body = document.querySelector('body');
        if(!body.classList.contains('js-scroll-jacked')) return;

        this.links.forEach((item) => {
            item.addEventListener('click', this.navClick.bind(this));
        });
    },

    navClick(e) {
        // the back to beginning button is handled in the ScrollHandler
        if(e.target.classList.contains('js-home')) return;
        e.preventDefault();

        let target = e.target.hash;
        let nextSlide = document.querySelector(`.slide${target}`);
        this.currentSection = target.substring(1);
        this.slides = Array.from(document.querySelectorAll('.slide'));
        let currentSlide = Array.from(document.querySelectorAll('.slide--active')).pop();

        this.currentSlideIndex = this.slides.indexOf(currentSlide);
        this.nextSlideIndex = this.slides.indexOf(nextSlide);

        if(this.currentSlideIndex > this.nextSlideIndex) {
            this.moveBackward();
        } else {
            this.moveForward();
        }


        this.updateScrollHandler();
    },

    updateScrollHandler() {
        ScrollHandler.slideIndex = this.nextSlideIndex;
        ScrollHandler.prevSlideIndex = this.nextSlideIndex - 1;
        ScrollHandler.afterSlide();
    },

    moveForward() {
        this.slides.forEach((item, index) => {
            if(index > this.currentSlideIndex && index <= this.nextSlideIndex) {
                item.classList.toggle('slide--active');
            }
            if(index > this.currentSlideIndex && index < this.nextSlideIndex) {
                item.classList.toggle('slide--past');
            }
        });
    },

    moveBackward() {
        this.slides.forEach((item, index) => {
            if(index > this.nextSlideIndex) {
                item.classList.remove('slide--active');
            }

            if(index >= this.nextSlideIndex) {
                item.classList.remove('slide--past');
            }
        });
    },

    setActiveNav() {
        this.links.find((item) => {
            item.classList.remove('main-nav__link--active');
            item.blur();
            if(item.hash == `#${ScrollHandler.activeSection}`) {
                if(item.classList.contains('main-nav__link')) {
                    item.classList.add('main-nav__link--active');
                }
            }
        });

        this.currentSection = ScrollHandler.activeSection;
        this.updateNavScroll();
    },

    updateNavScroll() {
        const navList = document.querySelector('.main-nav__list');
        const navIndex = this.links.findIndex((item) => item.hash == `#${this.currentSection}`);

        let width = 0;

        this.links.forEach((item, index) => {
            if(index < navIndex && item.classList.contains('main-nav__link')) {
                width += item.scrollWidth;
            }
        });

        if(window.innerWidth <= 1200 && navIndex > 1) {
            navList.parentElement.scroll({top: 0, left: width, behavior: 'smooth'});
        }
    },

    reset() {
        this.links.forEach((item) => {
            item.classList.remove('main-nav__link--active');
        });
    }

};
export default Navigation;
