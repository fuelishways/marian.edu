/**
 * Check for Internet Explorer 11.
 * @type {Object}
 */
const Browser = {
    uA: window.navigator.userAgent,
    isIEorEdge() {
        return /msie\s|trident\/|edge\//i.test(this.uA) && !!( document.uniqueID || window.MSInputMethodContext);
    },
    checkVersion() {
        if(this.isIEorEdge()) {
            return (this.isIEorEdge && +(/(edge\/|rv:|msie\s)([\d.]+)/i.exec(this.uA)[2])) || NaN;
        } else {
            return false;
        }

    }
};

export default Browser;
