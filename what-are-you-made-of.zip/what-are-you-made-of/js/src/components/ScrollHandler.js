import Browser from './Browser';
import Navigation from './Navigation';

const ScrollHandler = {
    // buttons
    nextButton: '.js-next',
    prevButton: '.js-prev',
    homeButton: '.js-home',

    // slides
    slideIndex: 0,
    slides: [],
    slideCount: 0,
    prevSlideIndex: 0,
    activeSection: '',

    // touch handler stuff
    dragThreshold: 0.15,
    dragStart: null,
    percentage: 0,
    target: '',
    previousTarget: '',

    init() {
        // Find all slides
        this.slides = Array.from(document.querySelectorAll('.slide'));
        // get the slide count
        this.slideCount = this.slides.length - 1;

        if(this.slideCount > 0 && Browser.checkVersion() === false || Browser.checkVersion() > 11) {
            // progressively enhance.
            let body = document.querySelector('body');
            body.classList.add('js-scroll-jacked');

            setTimeout(() => {
                this.slides.forEach((item) => {
                    item.classList.add('slide--animate');
                });
            }, 500);

            this.handleTouch();
            this.handleScroll();
            this.handleClicks();
            this.handleKeyUp();
        }

    },

    /**
     * Binds click events to DOM elements.
     *
     * Specifically, clicking on any button with the the this.nextButton class
     * will trigger the next slide. Clicking any button with the this.homeButton
     * class will trigger the reset.
     *
     */
    handleClicks() {
        // Click next
        const nextButtons = Array.from(document.querySelectorAll(this.nextButton));
        nextButtons.forEach((button) => {
            button.addEventListener('click', ScrollHandler.nextSlide.bind(ScrollHandler));
        });

        // Click back
        const prevButtons = Array.from(document.querySelectorAll(this.prevButton));
        prevButtons.forEach((button) => {
            button.addEventListener('click', ScrollHandler.prevSlide.bind(ScrollHandler));
        });

        // Reset
        const homeButtons = Array.from(document.querySelectorAll(this.homeButton));
        homeButtons.forEach((button) => {
            button.addEventListener('click', ScrollHandler.reset.bind(ScrollHandler));
        });
    },

    /**
     * Listen to mouse scrolling (wheel)
     * @return {[type]} [description]
     */
    handleScroll() {
        document.addEventListener('wheel', this.debounce(this.elementScroll.bind(this), 100, true));
    },

    /**
     * Handle touch events.
     */
    handleTouch() {
        document.addEventListener('touchstart', this.touchStart.bind(this));
        document.addEventListener('touchmove', this.touchMove.bind(this));
        document.addEventListener('touchend', this.touchEnd.bind(this));
    },

    /**
     * Handle keyboard events.
     */
    handleKeyUp() {
        document.addEventListener('keyup', ev => {
            let key = ev.keyCode;
            // left arrow triggers previous slide.
            if(key == 37) {
                ScrollHandler.prevSlide();
            // right arrow triggers next slide.
            } else if(key == 39) {
                ScrollHandler.nextSlide();
            // esc key triggers reset.
            } else if(key == 27) {
                ScrollHandler.reset();
            }
        });
    },

    /**
     * The core logic. Translates scroll information into slide direction.
     * @param  {Object} e the event object
     * @return {boolean}   false
     */
    elementScroll(e) {
        if(
            e.deltaY > 0 && e.deltaY ||
            e.deltaX > 0 && e.deltaX
        ) {
            this.nextSlide();
        }
        if(
            e.deltaY < 0 && Math.abs(e.deltaY) ||
            e.deltaX < 0 && Math.abs(e.deltaX)
        ) {
            this.prevSlide();
        }

        return false;
    },

    /**
     * Scroll to the previous slide. When the user gets to the first slide, don't
     * loop back around.
     *
     */
    prevSlide() {
        if(this.slideIndex <= 0) {
            this.reset();
        } else {
            this.showSlide();
            this.prevSlideIndex = this.slideIndex - 1;
            this.slides[this.prevSlideIndex].classList.remove('slide--past');
            this.slideIndex--;
            this.afterSlide();
        }
    },

    /**
     * Scroll to the next slide. When the user gets to the last slide,
     * loop around to the beginning.
     */
    nextSlide() {
        this.prevSlideIndex = this.slideIndex;
        this.slideIndex++;

        if(this.slideIndex > this.slideCount) {
            this.reset();
        } else {
            this.slides[this.prevSlideIndex].classList.add('slide--past');
            this.showSlide();
        }
        this.afterSlide();
    },

    /**
     * Show the next slide.
     */
    showSlide() {
        this.delta = 0;
        this.slides.forEach(item => {
            ScrollHandler.setTranslateX(item, 0);
        });
        this.slides[this.slideIndex].classList.toggle('slide--active');
    },

    /**
     * This function provides a hook for post slide event stuff.
     * If you need to do something based on slideIndex, this is the best place.
     */
    afterSlide() {
        this.setActiveSection();
        this.handleNavDisplay();
    },

    /**
     * Reset back to the beginning.
     */
    reset(e) {
        if(e) {
            e.preventDefault();
        }

        this.slideIndex = 0;
        this.prevSlideIndex = 0;

        this.slides.forEach((slide, index) => {
            if(index !== ScrollHandler.slideIndex) {
                slide.classList.remove('slide--active');
            }
            slide.classList.remove('slide--past');
            ScrollHandler.setTranslateX(slide, 0);
        });

        this.afterSlide();
        Navigation.reset();
    },

    touchStart(e) {
        if(e.target.classList.contains('main-nav__link', 'main-nav__list')) return;

        let event;
        if(this.dragStart !== null) return;
        if(e.touches) {
            event = e.touches[0];
        }

        this.dragStart = event.clientX;
        this.target = this.slides[this.slideIndex];
        this.target.classList.add('no-animation');

        if(this.slideIndex == this.slideCount) {
            this.nextTarget = this.slides[0];
        } else {
            this.nextTarget = this.slides[this.slideIndex+1];
        }

        this.nextTarget.classList.add('no-animation');

        // get the previous index, unless the current index is 0, then get the last one.
        if(this.slideIndex > 0) {
            this.previousTarget = this.slides[this.slideIndex-1];
        } else {
            this.previousTarget = this.slides[this.slideCount];
        }


        this.previousTarget.classList.add('no-animation');


    },

    touchMove(e) {
        if(e.target.classList.contains('main-nav__link', 'main-nav__list')) return;
        let event;

        // if we haven't created a drag start, abandon this function
        if(this.dragStart === null) return;
        if(e.touches) {
            event = e.touches[0];
        }

        this.delta = this.dragStart - event.clientX;

        // disallow backwards scrolling on landing.
        if(
            this.delta < 0 && e.target.classList.contains('landing') ||
            this.delta < 0 && e.target.classList.contains('landing__panel') ||
            this.delta < 0 && e.target.classList.contains('landing__title') ||
            this.delta < 0 && e.target.classList.contains('landing__title--large') ||
            this.delta < 0 && e.target.classList.contains('landing__title--small') ||
            this.delta < 0 && e.target.classList.contains('button')
        ) {
            return;
        }

        this.percentage = this.delta / window.innerHeight;

        // Bring in the next slide. Animate the transform.
        if(this.percentage > 0) {
            this.setTranslateX(this.nextTarget, `${100-(this.percentage*100)}%`);

            if(this.previousTarget) {
                this.setTranslateX(this.target, 0);
            }
        } else if (this.previousTarget) {
            // bring in the previous slide.
            this.setTranslateX(this.target, `${(-this.percentage*100)}%`);
        }

        return false;
    },

    touchEnd(e) {
        if(e.target.classList.contains('main-nav__link')) return;
        this.dragStart = null;
        this.target.classList.remove('no-animation');
        this.nextTarget.classList.remove('no-animation');

        if(this.previousTarget) {
            this.previousTarget.classList.remove('no-animation');
        }

        if(this.percentage >= this.dragThreshold) {
            this.nextSlide();
        } else if (this.percentage < 0 && Math.abs(this.percentage) >= this.dragThreshold && this.slideIndex > 0) {
            this.prevSlide();
        } else {
            // this.reset();
        }

        this.percentage = 0;
    },

    /**
     * Debounce function courtesy of David Walsh
     *
     * Returns a function, that, as long as it continues to be invoked, will not
     * be triggered. The function will be called after it stops being called for
     * N milliseconds. If `immediate` is passed, trigger the function on the
     * leading edge, instead of the trailing.
     *
     * https://davidwalsh.name/javascript-debounce-function
     * @param  {function} func     The function to be invoked.
     * @param  {integer} wait      The delay.
     * @param  {boolean} immediate Whether to invoke the function on the leading edge or trailing edge.
     * @return {function}           The function that we passed in.
     */
    debounce(func, wait, immediate) {
        var timeout;
        return function() {
            var context = this, args = arguments;
            var later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    },

    setTranslateX(el, value) {
        let transfromString = '';
        if(value != 0) {
            transfromString = `translateX(${value})`;
        }

        el.style.webkitTransform = transfromString;
        el.style.MozTransform = transfromString;
        el.style.msTransform = transfromString;
        el.style.OTransform = transfromString;
        el.style.transform = transfromString;
    },

    setActiveSection() {
        let slides = [...this.slides];
        // need to find closest previous slide with a target.
        let sections = [];

        slides.forEach((item, index) => {
            if(index <= this.slideIndex && item.id) {
                sections.push(item.id);
            }
        });

        this.activeSection = sections.pop();
        Navigation.setActiveNav();
    },

    handleNavDisplay() {
        let body = document.querySelector('body');
        if(window.innerHeight < 992 && this.slideIndex > 0) {

            body.classList.add('js-show-menu');
        } else if (window.innerHeight < 992 && this.slideIndex == 0) {
            body.classList.remove('js-show-menu');
        }
    }
};

export default ScrollHandler;
