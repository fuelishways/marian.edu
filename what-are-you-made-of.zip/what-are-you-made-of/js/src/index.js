import 'babel-polyfill';
import ScrollHandler from './components/ScrollHandler';
import Navigation from './components/Navigation';
import smoothscroll from 'smoothscroll-polyfill';
import ExternalLinks from './components/ExternalLinks';

smoothscroll.polyfill();


ScrollHandler.init();
Navigation.init();
ExternalLinks.init();
