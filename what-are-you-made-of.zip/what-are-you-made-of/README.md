# Marian University Viewbook Landing Page

 - [URLs](#urls)
 - [Local Dev](#local-dev)
 - [Deployment](#deployment)
 - [Important Notes](#important-notes)

## URLs

 - Live: http://findout.marian.edu
 - Staging: http://marianviewbook.upupdev.net
 - Local: http://localhost:3000

 - Live server: client hosted

## Local Dev
 1. Clone the repo.
 1. Run `yarn` or `npm install` to get all dependencies.
 1. Running `yarn run start` or `npm run start` will compile Sass, JS, SVG, and start a local development server at http://localhost:3000.


## Deployment
 - Run `yarn run build` or `npm run build` to compile Sass, JS, SVG for production. The Sass and JS will be significantly smaller than the dev versions.
 - **Staging**: Merge your changes into the testing branch and `cap staging deploy`.

## Important Notes
 none yet.
