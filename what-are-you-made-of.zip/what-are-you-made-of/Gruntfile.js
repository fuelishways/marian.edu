/* eslint-disable */
module.exports = function(grunt) {

    require('load-grunt-tasks')(grunt);

    grunt.initConfig({
        postcss: {
            options: {
                map: {
                    inline: false,
                    annotation: './css/dist/maps/'
                },

                processors: [
                    require('autoprefixer')({
                        browsers: [
                            'last 2 versions',
                            'ios 8',
                            'ie 9'
                        ]
                    }),
                    require('cssnano')({
                        options: {
                            sourcemap: true
                        },
                        dist: {
                            files: {
                                './css/dist/main.css': './css/dist/main.css'
                            }
                        }
                    })
                ]
            },
            dist: {
                src: './css/dist/*.css'
            }
        },
        sass: {
            devel: {
                options: {
                    update: true,
                    style: 'expanded',
                    sourcemap: 'auto'
                },
                files: {
                    './css/dist/main.css': './css/src/main.sass',
                }
            },
            prod: {
                options: {
                    update: true,
                    compass: true,
                    style: 'compressed'
                },
                files: {
                    './css/dist/main.css': './css/src/main.sass',
                }
            }
        },
        sasslint: {
            options: {
                configFile: '.sass-lint.yml'
            },
            target: ['css/src/**/*.sass']
        },
        svgmin: {
            dist: {
                files: [{
                    expand: true,
                    cwd: './img/svg/icons/',
                    src: ["*.svg"],
                    dest: "./img/svg/icons-optimized/"
                }]
            }
        },
        svgstore: {
            options: {
                svg: {
                    "xmlns": 'http://www.w3.org/2000/svg',
                    "xmlns:xlink": 'http://www.w3.org/1999/xlink'
                }
            },
            default: {
                files: {
                    "./img/svg/defs.svg": ["./img/svg/icons-optimized/*.svg"]
                }
            }
        },
        browserSync: {
            bsFiles: {
                src: [
                    'css/dist/main.css',
                    'js/dist/*',
                    'index.html'
                ]
            },
            options: {
                watchTask: true,
                server: {
                    baseDir: "./"
                }
            }
        },
        watch: {
            app: {
                files: [
                    './css/src/**/*.css',
                    './css/src/**/*.scss',
                    './css/src/**/*.sass',
                    './css/src/**/*.md'
                ],
                tasks: ['sasslint', 'sass:devel', 'postcss'],
                options: {
                    interrupt: true
                }
            },
            svg: {
                files: [
                    './img/svg/icons/*'
                ],
                tasks: ['svgmin', 'svgstore'],
                options: {
                    livereload: false,
                    spawn: false
                }
            }
        }
    });

    grunt.registerTask('default', ['browserSync', 'sasslint', 'sass:devel', 'postcss','svgmin', 'svgstore', 'watch']);
    grunt.registerTask('prod', ['sass:prod', 'postcss', 'svgmin', 'svgstore']);
    grunt.registerTask('dev', ['sass:devel', 'postcss', 'svgmin', 'svgstore']);

}
